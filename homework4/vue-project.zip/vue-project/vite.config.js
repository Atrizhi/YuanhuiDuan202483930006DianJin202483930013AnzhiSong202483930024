import { fileURLToPath, URL } from 'node:url'
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import vueDevTools from 'vite-plugin-vue-devtools'

// https://vite.dev/config/
export default defineConfig({
    plugins: [
        vue(),
        vueDevTools(),
    ],
    resolve: {
        alias: {
            '@': fileURLToPath(new URL('./src', import.meta.url))
        },
    },
    // 新增：代理配置（解决跨域核心）
    server: {
        // 开启代理
        proxy: {
            // 匹配所有以 /api 开头的请求
            '/api': {
                // 代理目标：后端 Spring Boot 服务地址
                target: 'http://localhost:8080',
                // 开启跨域代理（关键！伪装请求来源为后端地址）
                changeOrigin: true,
                // 重写路径：去掉 /api 前缀，后端只接收 /validate 而非 /api/validate
                rewrite: (path) => path.replace(/^\/api/, '')
            }
        }
    }
})