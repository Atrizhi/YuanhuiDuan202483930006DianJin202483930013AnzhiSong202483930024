package com.nuist.test.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration // 标识为配置类，Spring启动自动加载
public class CorsConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") // 对所有接口生效
                // 允许前端的地址（开发环境是5173，生产环境替换为实际域名）
                .allowedOrigins("http://localhost:5173")
                // 允许所有请求方式（GET/POST等）
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*") // 允许所有请求头
                .allowCredentials(true) // 允许携带Cookie（登录场景需要）
                .maxAge(3600); // 预检请求缓存1小时，减少OPTIONS请求
    }
}